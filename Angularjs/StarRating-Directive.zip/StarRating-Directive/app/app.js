﻿/// <reference path="../Scripts/angular.js" />
/// <reference path="../Scripts/angular.min.js" />

'use strict';

var app = angular.module('app', []);
